
from app.presentation.ui.main_window import run_app

if __name__ == "__main__":
    run_app()
